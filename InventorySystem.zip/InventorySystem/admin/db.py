import sqlite3

#Database connection
connection=sqlite3.connect("first.db")
cursor=connection.cursor()

#create table
cursor.execute("Create table if not exists user(id int auto_increment primary key,name text,gender text)")

#write data
cursor.execute("insert into user(name,gender) values(?,?)",("sandesh","M"))
connection.commit()

print("Table Created")
connection.close()
