<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management Software</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            overflow-x: hidden; /* Prevent horizontal scrolling */
        }
        .header {
            background-color: #0a3d62;
            color: white;
            padding: 20px;
            text-align: center;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1;
        }
        .header nav {
            display: flex;
            justify-content: space-around;
            padding: 10px;
        }
        .header nav a {
            color: white;
            text-decoration: none;
        }



        .dropdown { 
         position: relative;
        display: inline-block;
         } .dropdown-content
        { display: none;
         position: absolute;
        background-color: #0a3d62; 
        min-width: 160px; 
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1; 
    }
     .dropdown-content a { 
    color: black;
    padding: 12px 16px; 
    text-decoration: none; 
    display: block;
 
}
 .dropdown-content a:hover {
 background-color: #f1f1f1;
 } 
 .dropdown:hover .dropdown-content { 
    display: block;
 }

        .main-content {
            background-color: #191919;
            color: white;
            padding: 150px 50px 50px 50px; /* Adjust padding to account for fixed header */
            text-align: center;
            height: 2000px; /* Added height to allow scrolling */
        }
        .main-content h1 {
            margin-top: 0;
        }
        .button-demo {
            background-color: #ff6b6b;
            color: white;
            padding: 15px 30px;
            border: none;
            cursor: pointer;
            font-size: 1.2em;
        }
        .screenshots {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .screenshot {
            margin: 0 10px;
        }
        footer {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .popup {
            display: none; /* Hidden by default */
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid #ccc;
            background-color: darkblue;
            z-index: 2;
            width: 300px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .popup h2 {
            margin-top: 0;
        }
        .popup input {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
        }
        .popup button {
            padding: 10px 20px;
            background-color: #0a3d62;
            color: white;
            border: none;
            cursor: pointer;
        }
        .popup .close {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #aaa;
        }

        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.faq-container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #191919;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.faq-header {
    text-align: center;
    margin-bottom: 20px;
}

.faq-item {
    border: 1px solid #007bff;
    border-radius: 5px;
    margin-bottom: 10px;
}

.faq-question {
    background-color: #007bff;
    color: #fff;
    padding: 15px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.faq-answer {
    display: none;
    padding: 15px;
    background-color: #191919;
}

.faq-question.active + .faq-answer {
    display: block;
}



    </style>
</head>
<body>
    <div class="header">
        <nav>
       
            <a href="about.php" id="aboutBtn">About Us</a>
            <div class="dropdown"> 
         <a href="#" id="featuresBtn">Features</a>
          <div class="dropdown-content">
         <a href="#">Real-time Stock Tracking</a> 
         <a href="#">Order Management</a>
          <a href="#">Product Identification</a> 
          <a href="#">Automatic Report</a>
           <a href="#">Purchase Orders management</a>
            <a href="#">Billing</a> 
            <a href="#">Suppliers Record</a> 
            <a href="#">Automatic Calulation</a> 
        </div>
     </div>
            <a href="#" id="loginBtn">Login</a>  
     
            <div class="dropdown"> 
         <a href="#" id="contactBtn">Contact Us</a>
          <div class="dropdown-content">
     <a href="#">aakritipandit296@gmail.com</a>
     <a href="#">senaaashish@gmail.com</a>
         
        </div>
        </nav>
    </div>
    <div class="main-content">
        <h1>Inventory Management Software System</h1>
        <p>Our inventory management system allows users to efficiently manage stock levels of your products in real time.</p>
      
       
        <h1>What Is An Inventory Management System?</h1>
        <section>
            <p>Inventory management is the process of ensuring that adequate stock levels are maintained to avoid interruptions in a business’s day-to-day operations. Businesses manage their inventory around the clock as they purchase new products and ship orders to customers. It is essential for companies to have a simple, effective inventory management tool to help facilitate and streamline their day-to-day inventory processes. The pillars of a successful inventory management system include the following:</p>
        </section>
        <section>
            <h2>Inventory Levels</h2>
            <p>The total quantity of a specific item or product that is in-stock at a specific location. When you look up an item in our software it will prominently display the total in-stock quantity on the product details screen.</p>
        </section>



               <!-- Add your image here --> 
                <div class="image-section"> 
                <img src="homebg.png" alt="Description of image" width="500">




        <section>
            <h2>Orders</h2>
            <p>A record that authorizes the sale or purchase of specific items for a specific customer or from a specific vendor. You are able to place sales orders, and/or purchase orders within our software and process them to affect stock levels.</p>
        </section>
        <section>
            <h2>Product Identification</h2>
            <p>A means of uniquely identifying a specific item or group of items. Within Dynamic Inventory you are able to identify products using SKU, barcode, name, or custom fields.</p>
        </section>


               <!-- Add your image here --> 
               <div class="image-section"> 
                <img src="pagebg.png" alt="Description of image" width="1200">





    <div class="faq-container">
        <h2 class="faq-header">Frequently Asked Questions</h2>
        <div class="faq-item">
            <div class="faq-question">What is the maximum number of inventory items I can have in This Inventory?</div>
            <div class="faq-answer">This Inventory has no limit on the amount of products you can add in your database.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Does Dynamic Inventory track serial numbers, batches and lot numbers?</div>
            <div class="faq-answer">Yes, This  Inventory can track serial numbers, batches, and lot numbers.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Can I import my existing product data into the system?</div>
            <div class="faq-answer">Yes, you can import your existing product data into the system.</div>
        </div>
        <div class="faq-item">
            <div class="faq-question">Can I upload images and documents to an inventory item in This Inventory?</div>
            <div class="faq-answer">Yes, you can upload images and documents to an inventory item in  this Inventory.</div>
        </div>
    </div>
   
    <div class="popup" id="loginPopup">
        <span class="close" id="closePopup">&times;</span>
        <h2>Login</h2>
        <input type="text" placeholder="Username">
        <input type="password" placeholder="Password">
        <a href="adminhome.php">
    <button>Submit</button>
</a>

    </div>
     <footer> 
        <p>50°F Mostly cloudy</p> 
        <p id="time">
             <?php date_default_timezone_set('Asia/Kathmandu'); 
             echo date('h:i A d/m/Y'); 
             ?>
              </p>
    <script>
        const loginBtn = document.getElementById('loginBtn');
        const loginPopup = document.getElementById('loginPopup');
        const closePopup = document.getElementById('closePopup');

        loginBtn.addEventListener('click', () => {
            loginPopup.style.display = 'block';
        });

        closePopup.addEventListener('click', () => {
            loginPopup.style.display = 'none';
        });

        window.addEventListener('click', (event) => {
            if (event.target == loginPopup) {
                loginPopup.style.display = 'none';
            }
        });
    </script>


<script>
    document.querySelectorAll('.faq-question').forEach(item => {
    item.addEventListener('click', () => {
        item.classList.toggle('active');
        const answer = item.nextElementSibling;
        if (answer.style.display === 'block') {
            answer.style.display = 'none';
        } else {
            answer.style.display = 'block';
        }
    });
});
</script>




    <script>
        function updateTime() {
            const timeElement = document.getElementById('time');
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            const timeString = `${hours % 12 || 12}:${minutes} ${ampm}`;

            const day = now.getDate().toString().padStart(2, '0');
            const month = (now.getMonth() + 1).toString().padStart(2, '0');
            const year = now.getFullYear();

            timeElement.textContent = `${timeString} ${month}/${day}/${year}`;
        }

        // Update the time every second
        setInterval(updateTime, 1000);

        // Initial call to display the time immediately
        updateTime();
    </script>


</script>

</body>
</html>
