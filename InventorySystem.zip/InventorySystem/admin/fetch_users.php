<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "issystem");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch user data
$sql = "SELECT username FROM systemlog WHERE role = 'User'";
$result = $conn->query($sql);

$data = [];
$totalUsers = 0;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $totalUsers++;
        $username = $row['username'];
        if (!isset($data[$username])) {
            $data[$username] = 0;
        }
        $data[$username]++;
    }
} else {
    echo json_encode([]);
    exit;
}

// Close the connection
$conn->close();

// Convert data to format that Chart.js can use
$chartData = [
    'userData' => [],
    'totalUsers' => $totalUsers
];
foreach ($data as $username => $count) {
    $chartData['userData'][] = ['username' => $username, 'count' => $count];
}

// Output data in JSON format
echo json_encode($chartData);
?>
