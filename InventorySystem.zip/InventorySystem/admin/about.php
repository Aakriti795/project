<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Inventory - About Us</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<style>    

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color:rgb(158, 192, 231);
}

header {
    background-color: #fff;
    padding: 20px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}

.header-content h1 {
    font-size: 2em;
    margin: 0;
}

.header-content p {
    font-size: 1.2em;
    color: #555;
}

main {
    padding: 20px;
}

.content-section {
    background-color: #fff;
    padding: 20px;
    margin: 20px auto;
    max-width: 1000px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    gap: 20px;
}

.content-text {
    flex: 1;
}

.content-image img {
    display: block;
    max-width: 100%;
    height: auto;
    border-radius: 8px;
}




</style>
    <header>
        <div class="header-content">
            <h1>What is IS?</h1>
            <p>A flexible and user-friendly inventory management system designed with simplicity in mind.</p>
        </div>
    </header>
    <main>

   <center> <p>IS allows companies to efficiently track their inventory,<br>
                     products, vendors, purchases, and sales. We offer an affordable solution that <br>
                     solves many of the problems that only expensive systems solved in the past. Customer satisfaction <br>
                     is our priority.</p>  </center>
        <section class="content-section">
            <div class="content-text">
                
            </div>
            <div class="content-image">
                <img src="image.jpg" alt="Person using a laptop in a storage area">
            </div>
        </section>
    </main>
</body>
</html>
