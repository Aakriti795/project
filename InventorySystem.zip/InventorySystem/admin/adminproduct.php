<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
    SELECT 
        p.productid, 
        p.productname, 
        p.cp, 
        p.sp, 
        p.description, 
        p.Qty,
        s.name AS supplier_name
    FROM productinfo p
    LEFT JOIN supplier s ON p.suppliers = s.supid
";
$result = $conn->query($sql);

// Fetch supplier data from the database
$supplier_sql = "SELECT supid, name, phoneno, email FROM supplier";
$supplier_result = $conn->query($supplier_sql);

if ($supplier_result === false) {
    die("Error fetching suppliers: " . $conn->error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM productinfo WHERE productid = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: adminproduct.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle product update or insert
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['edit_productid'])) {
        // Update existing product
        $productid = intval($_POST['edit_productid']);
        $productname = $conn->real_escape_string($_POST['edit_productname']);
        $Qty = floatval($_POST['edit_qty']);
        $cp = floatval($_POST['edit_cp']);
        $sp = floatval($_POST['edit_sp']);
        $suppliers = intval($_POST['edit_suppliers']);
        $description = $conn->real_escape_string($_POST['edit_description']);

        $update_sql = "UPDATE productinfo SET 
                        productname = '$productname',
                        Qty = $Qty,
                        cp = $cp,
                        sp = $sp,
                        suppliers = $suppliers,
                        description = '$description'
                        WHERE productid = $productid";

        if ($conn->query($update_sql) === TRUE) {
            header("Location: adminproduct.php");
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }
    } else if (isset($_POST['add_product'])) {
        // Insert new product
        $productname = $conn->real_escape_string($_POST['productname']);
        $Qty = floatval($_POST['Qty']);
        $cp = floatval($_POST['cp']);
        $sp = floatval($_POST['sp']);
        $suppliers = intval($_POST['suppliers']);
        $description = $conn->real_escape_string($_POST['description']);

        $insert_sql = "INSERT INTO productinfo (productname, Qty, cp, sp, suppliers, description)
                    VALUES ('$productname', $Qty, $cp, $sp, $suppliers, '$description')";

        if ($conn->query($insert_sql) === TRUE) {
            header("Location: adminproduct.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
     
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>Suppliers</title>
    <link rel="stylesheet" href="adminhome.css">
    <style>
        /* Modal styles */
        .modal {
            display: none; /* Ensure the modal is hidden by default */
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 400px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-header {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .modal-body input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .modal-footer button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>
<body>
<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
    
    </aside>
    <main class="content">
        <header class="header">
            <h2>  &nbsp;  &nbsp;  &nbsp; Products</h2>
            <button class="btn" id="openAddModal">Add Product</button>
        </header>
        <section class="content">
            <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Cost Price</th>
                        <th>Selling Price</th>
                        <th>Supplier</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $product_data = json_encode([
                                'productid' => $row['productid'],
                                'productname' => $row['productname'],
                                'qty' => $row['Qty'],
                                'cp' => $row['cp'],
                                'sp' => $row['sp'],
                                'suppliers' => $row['supplier_name'],
                                'description' => $row['description']
                            ]);
                            echo "<tr>
                                <td>" . htmlspecialchars($row['productid']) . "</td>
                                <td>" . htmlspecialchars($row['productname']) . "</td>
                                <td>" . htmlspecialchars($row['Qty'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['cp'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['sp'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['supplier_name'] ?? 'N/A') . "</td>
                                <td>" . htmlspecialchars($row['description'] ?? '') . "</td>
                                <td>
                                   <a href='javascript:void(0);' class='btn btn-edit' data-product='$product_data'>Edit</a>
                                   <a href='adminproduct.php?delete_id=" . intval($row['productid']) . "' class='btn btn-delete' onclick='return confirm(\"Are you sure you want to delete this product?\");'>Delete</a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No data available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</div>

<!-- Modal for adding new product -->
<div class="modal" id="addProductModal">
    <div class="modal-content">
        <div class="modal-header">Add Product</div>
        <form id="addProductForm" action="adminproduct.php" method="post">
            <div class="modal-body">
                <input type="text" name="productname" id="productname" placeholder="Product Name" required>
                <input type="number" name="Qty" id="Qty" placeholder="Quantity" step="0.01" required>
                <input type="number" name="cp" id="cp" placeholder="Cost Price" step="0.01" required>
                <input type="number" name="sp" id="sp" placeholder="Selling Price" step="0.01" required>
                <select name="suppliers" id="suppliers" required>
                    <option value="" disabled selected>Select a supplier</option>
                    <?php
                    if ($supplier_result->num_rows > 0) {
                        while ($supplier_row = $supplier_result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($supplier_row['supid']) . "'>" . 
                                 htmlspecialchars($supplier_row['name']) . " - " . 
                                 htmlspecialchars($supplier_row['phoneno']) . " - " . 
                                 htmlspecialchars($supplier_row['email']) . "</option>";
                        }
                    }
                    ?>
                </select>
                <textarea name="description" id="description" rows="4" placeholder="Description" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeAddModal()">Cancel</button>
                <button type="submit" name="add_product" class="btn-primary">Add Product</button>
            </div>
        </form>
    </div>
</div>

<script>
// JavaScript to handle modal opening/closing
function closeAddModal() {
    document.getElementById('addProductModal').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
    const openAddModalButton = document.getElementById('openAddModal');
    const addProductModal = document.getElementById('addProductModal');

    openAddModalButton.addEventListener('click', () => {
        addProductModal.style.display = 'flex';
    });

    window.addEventListener('click', (event) => {
        if (event.target === addProductModal) {
            closeAddModal();
        }
    });
});
</script>

<!-- Modal for editing products -->
<div class="modal" id="editProductModal">
    <div class="modal-content">
        <div class="modal-header">Edit Product</div>
        <form id="editProductForm" action="adminproduct.php" method="post">
            <div class="modal-body">
                <input type="hidden" name="edit_productid" id="edit_productid">
                <input type="text" name="edit_productname" id="edit_productname" placeholder="Product Name" required>
                <input type="number" name="edit_qty" id="edit_qty" placeholder="Quantity" step="0.01" required>
                <input type="number" name="edit_cp" id="edit_cp" placeholder="Cost Price" step="0.01" required>
                <input type="number" name="edit_sp" id="edit_sp" placeholder="Selling Price" step="0.01" required>
                <select name="edit_suppliers" id="edit_suppliers" required>
                    <option value="" disabled>Select a supplier</option>
                    <?php
                    if ($supplier_result->num_rows > 0) {
                        while ($supplier_row = $supplier_result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($supplier_row['supid']) . "'>" . 
                                 htmlspecialchars($supplier_row['name']) . " - " . 
                                 htmlspecialchars($supplier_row['phoneno']) . " - " . 
                                 htmlspecialchars($supplier_row['email']) . "</option>";
                        }
                    }
                    ?>
                </select>
                <textarea name="edit_description" id="edit_description" rows="4" placeholder="Description" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
// JavaScript to open and close the modal
function closeEditModal() {
    document.getElementById('editProductModal').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
    function openEditModal(product) {
        document.getElementById('edit_productid').value = product.productid;
        document.getElementById('edit_productname').value = product.productname;
        document.getElementById('edit_qty').value = product.qty;
        document.getElementById('edit_cp').value = product.cp;
        document.getElementById('edit_sp').value = product.sp;
        document.getElementById('edit_description').value = product.description;

        // Set the supplier dropdown value
        const supplierDropdown = document.getElementById('edit_suppliers');
        Array.from(supplierDropdown.options).forEach(option => {
            option.selected = option.value == product.supplierid;
        });

        // Open the modal
        document.getElementById('editProductModal').style.display = 'flex';
    }

    window.addEventListener('click', (event) => {
        const modal = document.getElementById('editProductModal');
        if (event.target === modal) {
            closeEditModal();
        }
    });

    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', function() {
            const productData = JSON.parse(this.getAttribute('data-product'));
            openEditModal(productData);
        });
    });
});
</script>


</body>
</html>
