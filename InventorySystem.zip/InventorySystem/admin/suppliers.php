<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the suppliers table
$sql = "SELECT supid, name, phoneno, email FROM supplier";
$result = $conn->query($sql);

if ($result === false) {
    die("Error in SQL query: " . $conn->error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM supplier WHERE supid = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: suppliers.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Handle adding a new supplier
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['update_id'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $phoneno = $conn->real_escape_string($_POST['phoneno']);
    $email = $conn->real_escape_string($_POST['email']);

    $insert_sql = "INSERT INTO supplier (name, phoneno, email) VALUES ('$name', '$phoneno', '$email')";
    if ($conn->query($insert_sql) === TRUE) {
        header("Location: suppliers.php");
        exit();
    } else {
        echo "Error adding record: " . $conn->error;
    }
}

// Handle updating a supplier
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_id'])) {
    $update_id = intval($_POST['update_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $phoneno = $conn->real_escape_string($_POST['phoneno']);
    $email = $conn->real_escape_string($_POST['email']);

    $update_sql = "UPDATE supplier SET name = '$name', phoneno = '$phoneno', email = '$email' WHERE supid = $update_id";
    if ($conn->query($update_sql) === TRUE) {
        header("Location: suppliers.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
      
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>    Supplier</title>
    <link rel="stylesheet" href="adminhome.css">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 400px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-header {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .modal-body input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .modal-footer button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
    </style>
</head>
<body>
<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
        </aside>
    <main class="content">
        <header class="header">
            <h2>    &nbsp;  &nbsp;  &nbsp; Suppliers</h2>
            <button class="btn" id="openModal">Add Supplier</button>
        </header>
        <section class="content">
            <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left; border-collapse: collapse;">
                <thead>
                    <tr>
                        <th>Supplier ID</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>Email</th>
                        <th>Actions</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($row['supid']) . "</td>
                                    <td>" . htmlspecialchars($row['name']) . "</td>
                                    <td>" . htmlspecialchars($row['phoneno']) . "</td>
                                    <td>" . htmlspecialchars($row['email']) . "</td>
                                    <td>
                                        <button class='btn btn-edit' onclick='openUpdateModal(
                                            " . $row['supid'] . ",
                                            \"" . htmlspecialchars($row['name']) . "\",
                                            \"" . htmlspecialchars($row['phoneno']) . "\",
                                            \"" . htmlspecialchars($row['email']) . "\"
                                        )'>Edit</button>
                                        <a href='suppliers.php?delete_id=" . $row['supid'] . "' class='btn btn-delete' onclick='return confirm(\"Are you sure you want to delete this supplier?\");'>Delete</a>
                                    </td>
                                </tr>";

                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</div>

<!-- Modal -->
<div class="modal" id="supplierModal">
    <div class="modal-content">
        <div class="modal-header">Add New Supplier</div>
        <form id="supplierForm" action=" " method="post">
            <div class="modal-body">
                <input type="text" name="name" id="name" placeholder="Supplier Name" required>
                <input type="text" name="phoneno" id="phoneno" placeholder="Phone Number (10 digits)" required>
                <input type="email" name="email" id="email" placeholder="Email Address (e.g., example@gmail.com)" required>
                <p id="error-message" style="color: red; display: none;">Invalid email or phone number!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" id="closeModal">Cancel</button>
                <button type="submit" class="btn-primary">Add Supplier</button>
            </div>
        </form>
    </div>
</div>


<!-- Update Supplier Modal -->
<div class="modal" id="updateModal">
    <div class="modal-content">
        <div class="modal-header">Update Supplier</div>
        <form id="updateForm" action="suppliers.php" method="post">
            <div class="modal-body">
                <input type="hidden" name="update_id" id="update_id">
                <input type="text" name="name" id="update_name" placeholder="Supplier Name" required>
                <input type="text" name="phoneno" id="update_phoneno" placeholder="Phone Number (10 digits)" required>
                <input type="email" name="email" id="update_email" placeholder="Email Address" required>
                <option value="" disabled>Select a supplier</option>
                    <?php
                    if ($supplier_result->num_rows > 0) {
                        while ($supplier_row = $supplier_result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($supplier_row['supid']) . "'>" . 
                                 htmlspecialchars($supplier_row['name']) . " - " . 
                                 htmlspecialchars($supplier_row['phoneno']) . " - " . 
                                 htmlspecialchars($supplier_row['email']) . "</option>";
                        }
                    }
                    ?>
                </select>
                <textarea name="edit_description" id="edit_description" rows="4" placeholder="Description" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>



<script>
    // Modal functionality
    const modal = document.getElementById('supplierModal');
    const openModalBtn = document.getElementById('openModal');
    const closeModalBtn = document.getElementById('closeModal');
    const supplierForm = document.getElementById('supplierForm');
    const errorMessage = document.getElementById('error-message');

    openModalBtn.addEventListener('click', () => {
        modal.style.display = 'flex';
    });

    closeModalBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Form validation
    supplierForm.addEventListener('submit', (event) => {
        const phoneno = document.getElementById('phoneno').value;
        const email = document.getElementById('email').value;

        // Phone number must be exactly 10 digits
        const phoneRegex = /^\d{10}$/;

        // Email must contain @gmail.com
        const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

        if (!phoneRegex.test(phoneno) || !emailRegex.test(email)) {
            event.preventDefault(); // Prevent form submission
            errorMessage.style.display = 'block';
        } else {
            errorMessage.style.display = 'none';
        }
    });

    function openUpdateModal(id, name, phoneno, email) {
        document.getElementById('update_id').value = id;
        document.getElementById('update_name').value = name;
        document.getElementById('update_phoneno').value = phoneno;
        document.getElementById('update_email').value = email;
        document.getElementById('updateModal').style.display = 'flex';
    }
    
    function closeUpdateModal() {
        document.getElementById('updateModal').style.display = 'none';
    }
    

</script>
</body>
</html>
