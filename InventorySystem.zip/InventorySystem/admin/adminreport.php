
<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
    SELECT 
        p.productid, 
        p.productname, 
        p.cp, 
        p.sp, 
        p.description, 
        p.Qty,
        s.name AS supplier_name
    FROM productinfo p
    LEFT JOIN supplier s ON p.suppliers = s.supid
";
$result = $conn->query($sql);

// Fetch supplier data from the database
$supplier_sql = "SELECT supid, name, phoneno, email FROM supplier";
$supplier_result = $conn->query($supplier_sql);

if ($supplier_result === false) {
    die("Error fetching suppliers: " . $conn->error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM productinfo WHERE productid = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: adminproduct.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
//Handle insert/update request (post)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // ... (insert/update code remains the same)

}

//  *** prepare data for the chart (INTEGRATED HERE!) ***
$product_data = [];
$product_labels =[];

if ($result->num_rows > 0) {
    // Result the result pointer (ESSENTIAL!)
    $result->data_seek(0);
    while ($row = $result->fetch_assoc()) {
        $product_data[] = $row['Qty'];
        $product_labels[] = htmlspecialchars($row['productname']);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report</title>
    <link rel="stylesheet" href="adminhome.css">

    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


    <?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
    SELECT 
        p.productid, 
        p.productname, 
        p.cp, 
        p.sp, 
        p.description, 
        p.Qty,
        s.name AS supplier_name
    FROM productinfo p
    LEFT JOIN supplier s ON p.suppliers = s.supid
";
$result = $conn->query($sql);

// Fetch supplier data from the database
$supplier_sql = "SELECT supid, name, phoneno, email FROM supplier";
$supplier_result = $conn->query($supplier_sql);

if ($supplier_result === false) {
    die("Error fetching suppliers: " . $conn->error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM productinfo WHERE productid = $delete_id";
    if ($conn->query($delete_sql) === TRUE) {
        header("Location: adminproduct.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productname = $conn->real_escape_string($_POST['productname']);
    $Qty = floatval($_POST['Qty']);
    $cp = floatval($_POST['cp']);
    $sp = floatval($_POST['sp']);
    $description = $conn->real_escape_string($_POST['description']);

    // Handle the case where no supplier is selected
    $suppliers = isset($_POST['suppliers']) && !empty($_POST['suppliers']) ? intval($_POST['suppliers']) : 'NULL';

    $insert_sql = "INSERT INTO productinfo (productname, Qty, cp, sp, suppliers, description)
                    VALUES ('$productname', $Qty, $cp, $sp, $suppliers, '$description')";

    if ($conn->query($insert_sql) === TRUE) {
        header("Location: adminproduct.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suppliers</title>
    <link rel="stylesheet" href="adminhome.css">
    <style>
        /* Modal styles */
        .modal {
            display: none; /* Ensure the modal is hidden by default */
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 400px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-header {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .modal-body input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .modal-footer button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
    </style>

</head>
<body>

 
<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
        </aside>
        <main class="content">
            <header class="header">
                <h2>    &nbsp;  &nbsp;  &nbsp;Report</h2>
                
            </header>
            <br><br>
            <main>

            <h2>   &nbsp;  &nbsp;  &nbsp; Products Report  </h2>
            
        </header>
        <section class="content">
        <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Cost Price</th>
                    <th>Selling Price</th>
                    <th>Supplier</th>
                    <th>Description</th>
                   
                </tr>
            </thead>


           

            <canvas id="myChart" width="400" height="200"></canvas>





            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . htmlspecialchars($row['productid']) . "</td>
                            <td>" . htmlspecialchars($row['productname']) . "</td>
                            <td>" . htmlspecialchars($row['Qty'] ?? '0') . "</td>
                            <td>" . htmlspecialchars($row['cp'] ?? '0') . "</td>
                            <td>" . htmlspecialchars($row['sp'] ?? '0') . "</td>
                            <td>" . htmlspecialchars($row['supplier_name'] ?? 'N/A') . "</td>
                            <td>" . htmlspecialchars($row['description'] ?? '') . "</td>
                            
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No data available</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <canvas id="myChart" width="400" height="200"></canvas>

        </section>
    </main>
</div>
    
<!-- Modal for adding products -->
<div class="modal" id="productModal">
    <div class="modal-content">
        <div class="modal-header">Add Product</div>
        <form id="productForm" action="" method="post">
            <div class="modal-body">
                <input type="hidden" name="update_id" id="update_id">
                <input type="text" name="productname" id="productname" placeholder="Product Name" required>
                <input type="number" name="Qty" id="Qty" placeholder="Quantity" step="0.01" required>
                <input type="number" name="cp" id="cp" placeholder="Cost Price" step="0.01" required>
                <input type="number" name="sp" id="sp" placeholder="Selling Price" step="0.01" required>
                <select name="suppliers" id="suppliers" required>
                <option value="" disabled selected>Select a supplier</option>
                    <?php
                    if ($supplier_result->num_rows > 0) {
                        while ($supplier_row = $supplier_result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($supplier_row['supid']) . "'>" . 
                                    htmlspecialchars($supplier_row['name']) . " - " . 
                                    htmlspecialchars($supplier_row['phoneno']) . " - " . 
                                    htmlspecialchars($supplier_row['email']) . 
                                 "</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No suppliers available</option>";
                    }
                    ?>
                </select>
                
                <textarea name="description" id="description" rows="4" placeholder="Description" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn-primary">Add</button>
            </div>
        </form>
    </div>
</div>


<!-- Modal for editing products -->
<div class="modal" id="editProductModal">
  
        </main>
    </div>

    <script>
        function redirectToHome() {
            window.location.href = 'adminhome.php';
        }
    </script>


<script>
  const ctx = document.getElementById('myChart').getContext('2d');
  const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($product_labels); ?>,
      datasets: [{
        label: 'Product Quantity',
        data: <?php echo json_encode($product_data); ?>,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255, 99, 132, 1)',
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true
          }
        }]
      }
    }
  });
</script>


</body>
</html>

  