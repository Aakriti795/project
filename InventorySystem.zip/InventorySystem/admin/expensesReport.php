<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
    
   
<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="adminsetting.php"><i class="fas fa-cogs"></i> Setting</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
        </aside>
        </aside>
        <main class="content">
            <header class="header">
                <h2>Sales Report</h2>
                <button class="btn" onclick="location.href='salesReport.php'">Sales</button>
                <button class="btn" onclick="location.href='expensesReport.php'">Expenses</button>
                <button class="btn" onclick="location.href='returnReport.php'"></location>Return</button>
                
                
            </header>
            <br><br>
</body>
</html>