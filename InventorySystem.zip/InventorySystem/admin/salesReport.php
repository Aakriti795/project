<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .summary {
            margin-top: 20px;
        }
        .summary div {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    
    <div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                <li><a href="adminhome.php" class="active">Home</a></li>
                    <li><a href="user.php">User</a></li>
                    <li><a href="adminproduct.php">Product</a></li>
                    <li><a href="suppliers.php">Suppliers</a></li>
                    <li><a href="purchaseorder.php">purchase order</a></li>
                    <li><a href="adminreport.php">Report</a></li>
                    <li><a href="adminsetting.php" >Setting </a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="content">
            <header class="header">
                <h2>Sales Report</h2>
                <button class="btn" onclick="location.href='salesReport.php'">Sales</button>
                <button class="btn" onclick="location.href='expensesReport.php'">Expenses</button>
                <button class="btn" onclick="location.href='returnReport.php'"></location>Return</button>
                
            </header>
            <br><br>
            <main>
                    
    <table>
        <thead>
            <tr>
                <th>Bill No</th>
                <th>Item Name</th>
                <th>Price</th>
                <th>Qty</th>
                <th>Amount</th>
                <th>Time Stamp</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "issystem";
                
                $conn = new mysqli($servername, $username, $password, $dbname);
                
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
            ?>
        </tbody>
    </table>
            </main>
</body>
</html>