<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Report</title>
    <link rel="stylesheet" href="adminhome.css">
</head>
<body>
    
    <div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                <li><a href="adminhome.php" class="active">Home</a></li>
                    <li><a href="user.php">User</a></li>
                    <li><a href="adminproduct.php">Product</a></li>
                    <li><a href="suppliers.php">Suppliers</a></li>
                    <li><a href="purchaseorder.php">purchase order</a></li>
                    <li><a href="adminreport.php">Report</a></li>
                    <li><a href="adminsetting.php" >Setting </a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="content">
            <header class="header">
                <h2>Sales Report</h2>
                <button class="btn" onclick="location.href='salesReport.php'">Sales</button>
                <button class="btn" onclick="location.href='expensesReport.php'">Expenses</button>
                <button class="btn" onclick="location.href='returnReport.php'"></location>Return</button>
                
                
            </header>
            <br><br>
</body>
</html>