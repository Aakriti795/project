<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and capture form data
    $bill_to_company = mysqli_real_escape_string($conn, $_POST['bill_to_company']);
    $bill_to_address = mysqli_real_escape_string($conn, $_POST['bill_to_address']);
    $bill_to_city = mysqli_real_escape_string($conn, $_POST['bill_to_city']);
    $order_number = mysqli_real_escape_string($conn, $_POST['order_number']);
    $order_date = mysqli_real_escape_string($conn, $_POST['order_date']);
    $delivery_date = mysqli_real_escape_string($conn, $_POST['delivery_date']);
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);
    
    // Insert the purchase order data into the database (table: purchase_orders)
    $sql = "INSERT INTO purchase_orders (bill_to_company, bill_to_address, bill_to_city, order_number, order_date, delivery_date, notes)
            VALUES ('$bill_to_company', '$bill_to_address', '$bill_to_city', '$order_number', '$order_date', '$delivery_date', '$notes')";

    if ($conn->query($sql) === TRUE) {
        $purchase_order_id = $conn->insert_id;  // Get the ID of the inserted order

        // Insert the order items into the order_item table
        for ($i = 1; isset($_POST["description$i"]); $i++) {
            $description = mysqli_real_escape_string($conn, $_POST["description$i"]);
            $quantity = mysqli_real_escape_string($conn, $_POST["quantity$i"]);
            $rate = mysqli_real_escape_string($conn, $_POST["rate$i"]);
            $amount = mysqli_real_escape_string($conn, $_POST["amount$i"]);

            $sql_item = "INSERT INTO order_item (purchase_order_id, description, quantity, rate, amount)
                         VALUES ('$purchase_order_id', '$description', '$quantity', '$rate', '$amount')";
            $conn->query($sql_item);
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch purchase orders and items for display
$orders_result = $conn->query("SELECT * FROM purchase_orders ORDER BY id DESC");

?>


<!DOCTYPE html>
<html lang="en">
<head>
   
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

    <style>
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 400px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .modal-header {
            font-size: 18px;
            margin-bottom: 10px;
        }
        .modal-body input {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .modal-footer button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }
        /* Purchase Order Styles */
        .container {
            width: 80%;
            margin: 0 auto;
            border: 1px solid #ccc;
            padding: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .company-info {
            width: 40%;
        }
        .order-info {
            width: 40%;
            text-align: right;
        }
        h1 {
            color: orange;
        }
        .bill-to {
            background-color: #ffe0cc; /* Light orange background */
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .totals {
            text-align: right;
        }
        .notes {
            margin-top: 20px;
            font-style: italic;
        }
        .orange-bg {
            background-color: #ffe0cc;
            padding: 5px;
        }
    </style>
</head>
<body>

<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
        </aside>
    <main class="content">
        <header class="header">
            <h2>     &nbsp;  &nbsp;  &nbsp; Purchase Order</h2>
           
        </header>
        <section class="content">
            <!-- Purchase Order Form -->


            
            <form action="purchaseorder.php" method="POST">
                <div class="container">
                    <div class="header">
                        <div class="company-info">
                            <strong>A cube Team</strong><br>
                            Address: Vyas,1<br>
                            City: Damauli<br>
                            Email Address: acubeteam@gmail.com
                        </div>
                        <div class="order-info">
                            <h1>Purchase Order</h1>
                        </div>
                    </div>

                    <div class="bill-to orange-bg">
                        <strong>Order To</strong><br>
                        <input type="text" name="bill_to_company" placeholder="Company Name"><br>
                        <input type="text" name="bill_to_address" placeholder="Address"><br>
                        <input type="text" name="bill_to_city" placeholder="City/State"><br>
                    </div>

                    <div class="order-details">
                        <div class="orange-bg">
                            <strong>Purchase Order#:</strong><br>
                            <input type="text" name="order_number" placeholder="Order Number"><br>
                            <strong>Date:</strong><br>
                            <input type="date" name="order_date" placeholder="Date"><br>
                            <strong>Delivery Date:</strong><br>
                            <input type="date" name="delivery_date" placeholder="Delivery Date">
                        </div>

                        <table id="order-table">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Rate</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td><input type="text" class="input-field" name="description1" placeholder="Item Name"></td>
                                    <td><input type="number" class="input-field" name="quantity1" placeholder="Quantity" oninput="calculateAmount(1)"></td>
                                    <td><input type="number" class="input-field" name="rate1" placeholder="Price/Unit" oninput="calculateAmount(1)"></td>
                                    <td><input type="number" class="input-field" name="amount1" placeholder="Amount" readonly></td>
                                    <td>
                                        <button type="button" onclick="deleteRow(this)">Delete</button>
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4"><strong>Total</strong></td>
                                    <td><strong><span id="total-amount">Rs 0.00</span></strong></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>

                        <button type="button" onclick="addItem()">Add Item</button>
                    </div>

                    <div class="notes">
                        <strong>Notes:</strong><br>
                        <textarea name="notes" rows="4" placeholder="Comments can go here"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit Order</button>
                </div>
            </form>




            <!-- Display the Table with User's Submitted Data -->
            <div class="table-container">
                <?php if ($orders_result->num_rows > 0): ?>
                    <h2>Purchase Orders</h2>
                    <?php while($order = $orders_result->fetch_assoc()): ?>
                        <h3>Order Number: <?php echo $order['order_number']; ?></h3>
                        <table>
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Rate</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $order_id = $order['id'];
                                $sql_items = "SELECT * FROM order_item WHERE purchase_order_id = $order_id";
                                $items_result = $conn->query($sql_items);
                                $item_number = 1;
                                while ($item = $items_result->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td><?php echo $item_number++; ?></td>
                                        <td><?php echo $item['description']; ?></td>
                                        <td><?php echo $item['quantity']; ?></td>
                                        <td><?php echo $item['rate']; ?></td>
                                        <td><?php echo $item['amount']; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No orders have been placed yet.</p>
                <?php endif; ?>
            </div>

        </section>
    </main>
</div>

<script>


    function addItem() {
        itemCount++;
        const table = document.getElementById('order-table').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();
        newRow.innerHTML = `
            <td>${itemCount}</td>
            <td><input type="text" name="description${itemCount}" placeholder="Item Name"></td>
            <td><input type="number" name="quantity${itemCount}" placeholder="Quantity" oninput="calculateAmount(${itemCount})"></td>
            <td><input type="number" name="rate${itemCount}" placeholder="Price/Unit" oninput="calculateAmount(${itemCount})"></td>
            <td><input type="number" name="amount${itemCount}" placeholder="Amount" readonly></td>
            <td><button type="button" onclick="deleteRow(this)">Delete</button></td>
        `;
    }

    function calculateAmount(itemNumber) {
        const quantity = document.querySelector(`input[name="quantity${itemNumber}"]`).value;
        const rate = document.querySelector(`input[name="rate${itemNumber}"]`).value;
        const amountField = document.querySelector(`input[name="amount${itemNumber}"]`);
        const totalField = document.getElementById("total-amount");

        if (quantity && rate) {
            const amount = parseFloat(quantity) * parseFloat(rate);
            amountField.value = amount.toFixed(2); // Ensure amount is displayed with two decimal places

            updateTotal();
        } else {
            amountField.value = '0.00';
            updateTotal();
        }
    }

    function updateTotal() {
        let total = 0;
        const amountFields = document.querySelectorAll("input[name^='amount']");

        amountFields.forEach(field => {
            total += parseFloat(field.value) || 0;
        });

        document.getElementById("total-amount").textContent = `Rs ${total.toFixed(2)}`;
    }

    function deleteRow(button) {
        const row = button.closest('tr');
        row.remove();
        updateTotal();
    }
</script>
<script>
    let itemCount = 1;

    function addItem() {
        itemCount++;
        const table = document.getElementById('order-table').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();
        newRow.innerHTML = `
            <td>${itemCount}</td>
            <td><input type="text" name="description${itemCount}" placeholder="Item Name"></td>
            <td><input type="number" name="quantity${itemCount}" placeholder="Quantity"></td>
            <td><input type="number" name="rate${itemCount}" placeholder="Price/Unit"></td>
            <td><input type="number" name="amount${itemCount}" placeholder="Amount" readonly></td>
            <td><button type="button" onclick="deleteRow(this)">Delete</button></td>
        `;
    }

    function deleteRow(button) {
        const row = button.closest('tr');
        row.remove();
    }
</script>

</body>
</html>
