

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="adminhome.css">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            
            <li><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
           
         </ul>
            </nav>
        </aside>
       
                <div class="card">
                
                <section class="graph-section">

    <h2> Admin Dashboard</h2>
    <h3>  User Details Bar Chart</h3>
    <canvas id="userBarChart" width="400" height="200"></canvas>
    <div id="totalUserCount" class="highlighted-text"></div>
</section>




</section>

</section>

                </div>
               
             
            </section>
          
        </main>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
    const ctx = document.getElementById('userScatterChart').getContext('2d');

    let scatterChart = new Chart(ctx, {
        type: 'scatter',
        data: { datasets: [{ label: 'User Data', data: [], backgroundColor: '#3498db' }] },
        options: {
            responsive: true,
            scales: {
                x: { title: { display: true, text: 'Username Length' }, beginAtZero: true },
                y: { title: { display: true, text: 'Password Length' }, beginAtZero: true }
            }
        }
    });

    const fetchUserData = () => {
        fetch('fetch_users.php')
            .then(response => response.json())
            .then(data => {
                scatterChart.data.datasets[0].data = data;
                scatterChart.update();
            })
            .catch(err => console.error('Error fetching data:', err));
    };

    fetchUserData(); // Initial load
    setInterval(fetchUserData, 5000); // Auto-refresh every 5 seconds
});
</script>


<script>
document.addEventListener("DOMContentLoaded", () => {
    const ctx = document.getElementById('userBarChart').getContext('2d');
    const totalUserCountElem = document.getElementById('totalUserCount');

    const generateRandomColor = () => {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };

    const barColors = [];

    const fetchUserData = () => {
        fetch('fetch_users.php')
            .then(response => response.json())
            .then(data => {
                console.log('Data fetched:', data);
                const userData = data.userData;
                const totalUsers = data.totalUsers;

                const usernames = userData.map(item => item.username);
                const counts = userData.map(item => item.count);

                // Generate a color for each bar
                while (barColors.length < userData.length) {
                    barColors.push(generateRandomColor());
                }

                barChart.data.labels = usernames;
                barChart.data.datasets[0].data = counts;
                barChart.data.datasets[0].backgroundColor = barColors;
                barChart.update();

                // Display total number of users
                totalUserCountElem.innerText = ` Total Number of Users: ${totalUsers}`;
            })
            .catch(err => console.error('Error fetching data:', err));
    };

    let barChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [], // Usernames
            datasets: [{
                label: 'Number of Users',
                data: [], // User counts
                backgroundColor: barColors
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: { display: true, text: 'Usernames' }
                },
                y: {
                    title: { display: true, text: 'Number of Users' },
                    beginAtZero: true
                }
            }
        }
    });

    fetchUserData(); // Initial load
    setInterval(fetchUserData, 5000); // Auto-refresh every 5 seconds
});

</script>




    
</body>
</html>