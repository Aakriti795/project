<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = new mysqli("localhost", "root", "", "issystem");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Add user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);
    $role = 'User';
    if (!empty($username) && !empty($password)) {
        $sql = "INSERT INTO systemlog (username, password, role) VALUES ('$username', '$password', '$role')";
        if (!$conn->query($sql)) echo "<script>alert('Error: " . $conn->error . "');</script>";
    } else echo "<script>alert('Please fill out all fields');</script>";
}

// Edit user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_user'])) {
    $uid = $conn->real_escape_string($_POST['user_id']);
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);
    if (!empty($uid) && !empty($username) && !empty($password)) {
        $sql = "UPDATE systemlog SET username='$username', password='$password' WHERE uid=$uid";
        if (!$conn->query($sql)) echo "<script>alert('Error: " . $conn->error . "');</script>";
    } else echo "<script>alert('Please fill out all fields');</script>";
}

// Fetch users
$result = $conn->query("SELECT uid, username, password FROM systemlog WHERE role = 'User'");
if ($result === false) die("Error in SQL query: " . $conn->error);
?>
<!DOCTYPE html>
<html lang="en">
<head>
     
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User management</title>
    <link rel="stylesheet" href="adminhome.css">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Report</title>
    <link rel="stylesheet" href="adminhome.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .modal { display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4); }
        .modal-content { background-color: #fefefe; margin: 10% auto; padding: 20px; border-radius: 8px; width: 30%; }
        .close { float: right; font-size: 28px; cursor: pointer; }
    </style>
</head>
<body>

<style>
        header {
            background-color: #3498db; /* Change this to your desired color */
            padding: 20px;
        }
        h2 {
            margin: 0;
            color: #fefefe; /* Set text color to white */
        }
    </style>

<div class="dashboard">
        <aside class="sidebar">
        <img src="logo.png" alt="System logo" class="logo">
            <nav>
            <ul> 
            <li><a href="adminhome.php" class="active"><i class="fas fa-home"></i> Home</a></li> 
            <li><a href="user.php"><i class="fas fa-user"></i> User</a></li> 
            <li><a href="adminproduct.php"><i class="fas fa-box"></i> Product</a></li> 
            <li><a href="suppliers.php"><i class="fas fa-truck"></i> Suppliers</a></li> 
            <li><a href="purchaseorder.php"><i class="fas fa-receipt"></i> Purchase Order</a></li>
            <li><a href="adminreport.php"><i class="fas fa-chart-line"></i> Report</a></li>
            <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
         </ul>
            </nav>
        
        </aside>
    </aside>
    <main class="content">
        <header> <h2>   &nbsp;       &nbsp;   User Details</h2>
        &nbsp;     &nbsp;   &nbsp;  <button class="btn" id="addUserBtn">    &nbsp;   &nbsp;  Add User</button></header>

        &nbsp; 
        &nbsp;   <table border="1" style="width:100%;text-align:left;border-collapse:collapse;">

        &nbsp;  &nbsp; &nbsp; 
            <thead><tr><th>   &nbsp;   &nbsp;   &nbsp; UID</th><th>Username</th><th>Password</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['uid']) ?></td>
                    <td><?= htmlspecialchars($row['username']) ?></td>
                    <td><?= htmlspecialchars($row['password']) ?></td>
                    <td>
                        <button class="btn" onclick="openEditUserModal(<?= $row['uid'] ?>, '<?= htmlspecialchars($row['username']) ?>')">Edit</button>
                        <a href="delete_user.php?uid=<?= $row['uid'] ?>" onclick="return confirm('Delete user?');" class="btn">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</div>

<!-- Add User Modal -->
<div id="addUserModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h3>Add User</h3>
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" name="username" required><br><br>
            <label for="password">Password:</label>
            <input type="password" name="password" required><br><br>
            <button type="submit" name="add_user" class="btn">Add User</button>
        </form>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeEditModal">&times;</span>
        <h3>Edit User</h3>
        <form method="POST" action="">
            <input type="hidden" name="user_id" id="edit_user_id">
            <label for="edit_username">Username:</label>
            <input type="text" name="username" id="edit_username" required><br><br>
            <label for="edit_password">Password:</label>
            <input type="password" name="password" id="edit_password" required><br><br>
            <button type="submit" name="edit_user" class="btn">Save Changes</button>
        </form>
    </div>
</div>

<script>
    const addUserModal = document.getElementById('addUserModal'), editUserModal = document.getElementById('editUserModal');
    const closeModal = document.getElementById('closeModal'), closeEditModal = document.getElementById('closeEditModal');
    const editUserId = document.getElementById('edit_user_id'), editUsername = document.getElementById('edit_username'), editPassword = document.getElementById('edit_password');

    document.getElementById('addUserBtn').onclick = () => addUserModal.style.display = "block";
    closeModal.onclick = () => addUserModal.style.display = "none";
    closeEditModal.onclick = () => editUserModal.style.display = "none";

    window.onclick = e => { if (e.target === addUserModal) addUserModal.style.display = "none"; if (e.target === editUserModal) editUserModal.style.display = "none"; }

    function openEditUserModal(uid, username) {
        editUserId.value = uid;
        editUsername.value = username;
        editPassword.value = "";
        editUserModal.style.display = "block";
    }
</script>
</body>
</html>
