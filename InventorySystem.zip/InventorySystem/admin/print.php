<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Bill</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
        }

        .bill-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .bill-header img {
            max-width: 100px;
        }

        .bill-header h1 {
            margin: 5px 0;
        }

        .bill-header p {
            margin: 3px 0;
        }

        .bill-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .bill-table th, .bill-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .bill-table th {
            background-color: #f2f2f2;
        }

        .totals {
            text-align: right;
            margin-top: 20px;
        }

        .totals strong {
            font-size: 1.1em;
        }

        .actions {
            text-align: center;
            margin-top: 30px;
        }

        @media print {
            .actions {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="bill-header">
    <img src="logo.png" alt="Company Logo">
    <h1>A Cube Pvt Ltd</h1>
    <p>Phone: 9826162026</p>
    <p>Email: acubepvtltd@gmail.com</p>
</div>

<table class="bill-table">
    <thead>
    <tr>
        <th>S.N</th>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Price/Unit (Rs)</th>
        <th>Amount (Rs)</th>
    </tr>
    </thead>
    <tbody id="bill-body">
    <tr>
        <td>1</td>
        <td>Sample Item</td>
        <td>2</td>
        <td>100</td>
        <td>200</td>
    </tr>
    <!-- Additional rows will go here -->
    </tbody>
</table>

<div class="totals">
    <p><strong>Total Amount:</strong> Rs 200.00</p>
    <p><strong>Invoice Amount in Words:</strong> Two Hundred Rupees only</p>
    <p><strong>Received:</strong> Rs 150.00</p>
    <p><strong>Balance:</strong> Rs 50.00</p>
</div>

<div class="actions">
    <button onclick="window.print()">Print</button>
</div>

</body>
</html>
