<?php
session_start();

$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "issystem"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = ""; // To store error messages

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);


    // Query to validate credentials
    $sql = "SELECT uid, role FROM systemlog WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $_SESSION['uid'] = $row['uid'];
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $row['role'];

        // Redirect based on role
        if ($row['role'] === 'Admin') {
            header("Location: admin/adminhome.php");
        } elseif ($row['role'] === 'User') {
            header("Location:user/userhome.php");
        } else {
            $error = "Unknown role. Please contact support.";
        }
        exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management Software</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            overflow-x: hidden; /* Prevent horizontal scrolling */
        }
        .header {
            background-color: #0a3d62;
            color: white;
            padding: 20px;
            text-align: center;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1;
        }
        .header nav {
            display: flex;
            justify-content: space-around;
            padding: 10px;
        }
        .header nav a {
            color: white;
            text-decoration: none;
        }

        .dropdown { 
            position: relative;
            display: inline-block;
        } 
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #0a3d62; 
            min-width: 160px; 
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1; 
        }
        .dropdown-content a { 
            color: black;
            padding: 12px 16px; 
            text-decoration: none; 
            display: block;
        }
        .dropdown-content a:hover {
            background-color:rgb(12, 2, 2);
        } 
        .dropdown:hover .dropdown-content { 
            display: block;
        }

        .main-content {
            background-color: #191919;
            color: white;
            padding: 150px 50px 50px 50px; /* Adjust padding to account for fixed header */
            text-align: center;
            height: 2000px; /* Added height to allow scrolling */
        }
        .main-content h1 {
            margin-top: 0;
        }
        .button-demo {
            background-color: #ff6b6b;
            color: white;
            padding: 15px 30px;
            border: none;
            cursor: pointer;
            font-size: 1.2em;
        }
        .screenshots {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }
        .screenshot {
            margin: 0 10px;
        }
        footer {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        .popup {
            display: none; /* Hidden by default */
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 1px solid #ccc;
            background-color: darkblue;
            z-index: 2;
            width: 300px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .popup h2 {
            margin-top: 0;
        }
        .popup input {
            width: calc(100% - 20px);
            padding: 8px;
            margin: 10px 0;
            border: 1px solid #ddd;
        }
        .popup button {
            padding: 10px 20px;
            background-color: #0a3d62;
            color: white;
            border: none;
            cursor: pointer;
        }
        .popup .close {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            color: #aaa;
        }

        .faq-container {
            max-width: 800px;
            margin: 50px auto;
            background-color: #191919;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .faq-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .faq-item {
            border: 1px solid #007bff;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .faq-question {
            background-color: #007bff;
            color: #fff;
            padding: 15px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .faq-answer {
            display: none;
            padding: 15px;
            background-color: #191919;
        }

        .faq-question.active + .faq-answer {
            display: block;
        }
    </style>
</head>
<body>
    <div class="header">
        <nav>
            <a href="aboutus.php" id="aboutBtn">About Us</a>
            <div class="dropdown"> 
                <a href="#" id="featuresBtn">Features</a>
                <div class="dropdown-content">
                    <a href="#">User Details</a> 
                    <a href="#">Product Identification</a>
                    <a href="#">Suppliers Identification</a> 
                    <a href="#">Automatic Report</a>
                    <a href="#">Purchase Orders management</a>
                    <a href="#">Billing</a> 
                    <a href="#">Bill History</a> 
                    <a href="#">Suppliers Record</a> 
                    <a href="#">Automatic Calculation</a> 
                </div>
            </div>
            <a href="#" id="loginBtn">Login</a>  
            <div class="dropdown"> 
                <a href="#" id="contactBtn">Contact Us</a>
                <div class="dropdown-content">
                    <a href="#">aakritipandit296@gmail.com</a>
                    <a href="#">senaaashish@gmail.com</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="main-content">
        <h1>Inventory Management Software System</h1>
        <p>Our inventory management system allows users to efficiently manage stock levels of your products in real time.</p>
        
       
        </section>

        <!-- Add your image here --> 
        <div class="image-section"> 
            <img src="firstimage.jpg" alt="Description of image" width="1200">
        </div>

        <div class="faq-container">
            <h2 class="faq-header">Frequently Asked Questions</h2>
            <div class="faq-item">
                <div class="faq-question">What is the maximum number of inventory items I can have in This Inventory?</div>
                <div class="faq-answer">This Inventory has no limit on the amount of products you can add in your database.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">Does Dynamic Inventory track serial numbers, batches and lot numbers?</div>
                <div class="faq-answer">Yes, This Inventory can track serial numbers, batches, and lot numbers.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">Can I import my existing product data into the system?</div>
                <div class="faq-answer">Yes, you can import your existing product data into the system.</div>
            </div>
            <div class="faq-item">
                <div class="faq-question">Can I upload images and documents to an inventory item in This Inventory?</div>
                <div class="faq-answer">Yes, you can upload images and documents to an inventory item in this Inventory.</div>
            </div>
        </div>
    </div>

    <div class="popup" id="loginPopup">
        <span class="close" id="closePopup">&times;</span>
        <h2>Login</h2>
        <?php if (!empty($error)): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    
    <footer> 
        <p>50°F Mostly cloudy</p> 
        <p id="time">
            <?php 
                date_default_timezone_set('Asia/Kathmandu'); 
                echo date('h:i A d/m/Y'); 
            ?>
        </p>
    </footer>

    <script>
        const loginBtn = document.getElementById('loginBtn');
        const loginPopup = document.getElementById('loginPopup');
        const closePopup = document.getElementById('closePopup');

        loginBtn.addEventListener('click', () => {
            loginPopup.style.display = 'block';
        });

        closePopup.addEventListener('click', () => {
            loginPopup.style.display = 'none';
        });

        window.addEventListener('click', (event) => {
            if (event.target == loginPopup) {
                loginPopup.style.display = 'none';
            }
        });
    </script>

    <script>
        document.querySelectorAll('.faq-question').forEach(item => {
            item.addEventListener('click', () => {
                item.classList.toggle('active');
                const answer = item.nextElementSibling;
                if (answer.style.display === 'block') {
                    answer.style.display = 'none';
                } else {
                    answer.style.display = 'block';
                }
            });
        });
    </script>

    <script>
        function updateTime() {
            const timeElement = document.getElementById('time');
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            const timeString = `${hours % 12 || 12}:${minutes} ${ampm}`;

            const day = now.getDate().toString().padStart(2, '0');
            const month = (now.getMonth() + 1).toString().padStart(2, '0');
            const year = now.getFullYear();

            timeElement.textContent = `${timeString} ${month}/${day}/${year}`;
        }

        // Update the time every second
        setInterval(updateTime, 1000);

        // Initial call to display the time immediately
        updateTime();
    </script>
</body>
</html>
