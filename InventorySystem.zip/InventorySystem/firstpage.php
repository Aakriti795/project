<?php
session_start();
$host = 'localhost';
$user = 'root'; 
$password = ''; 
$database = 'issystem'; 
$errorMessage = '';

$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT logo FROM basicinfo LIMIT 1";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $logoURL = 'logoimages/' . $row['logo'];
} else {
    $logoURL = 'default-logo.png'; // Fallback logo if database query fails
}


// Fetch login types
$roles = [];
$roleQuery = "SELECT rid, name FROM role";
$roleResult = $conn->query($roleQuery);
if ($roleResult && $roleResult->num_rows > 0) {
    while ($roleRow = $roleResult->fetch_assoc()) {
        $roles[] = $roleRow;
    }
}


//code for login modal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] == 1) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $conn->real_escape_string($_POST['password']);
    $user_type = (int)$conn->real_escape_string($_POST['user_type']);

    //role name from the role table
    $roleQuery = "SELECT name FROM role WHERE rid = $user_type";
    $roleResult = $conn->query($roleQuery);

    if ($roleResult && $roleResult->num_rows === 1) {
        $roleRow = $roleResult->fetch_assoc();
        $roleName = strtolower($roleRow['name']); 

        if ($roleName === 'admin') {
            // Validate Admin Login
            $query = "SELECT * FROM adminlog WHERE username = '$username' AND password = '$password'";
            $result = $conn->query($query);

            if ($result && $result->num_rows === 1) {
                $admin = $result->fetch_assoc();
                $_SESSION['user_id'] = $admin['aid'];
                $_SESSION['user_name'] = $admin['name'];
                $_SESSION['user_username'] = $admin['username'];
                $_SESSION['user_type'] = 'Admin';
                $response = ['success' => true, 'redirect' => 'adminpages/admindashboard.php'];
            }
        } elseif ($roleName === 'faculty head') {
            // Validate Faculty Head Login
            $query = "SELECT * FROM stafflog WHERE username = '$username' AND password = '$password' AND role = $user_type";
            $result = $conn->query($query);

            if ($result && $result->num_rows === 1) {
                $staff = $result->fetch_assoc();
                $_SESSION['user_id'] = $staff['stid'];
                $_SESSION['user_name'] = $staff['name'];
                $_SESSION['user_username'] = $staff['username'];
                $_SESSION['user_type'] = 'Faculty Head';
                $_SESSION['faculty_type'] = $staff['faculty_id'];
                $response = ['success' => true, 'redirect' => 'facultyheadpages/facultyheaddashboard.php'];
            }
        } elseif ($roleName === 'teacher') {
            // Validate Teacher Login
            $query = "SELECT * FROM stafflog WHERE username = '$username' AND password = '$password' AND role = $user_type";
            $result = $conn->query($query);

            if ($result && $result->num_rows === 1) {
                $staff = $result->fetch_assoc();
                $_SESSION['user_id'] = $staff['stid'];
                $_SESSION['user_name'] = $staff['name'];
                $_SESSION['user_username'] = $staff['username'];
                $_SESSION['user_type'] = 'Teacher';
                $_SESSION['faculty_type'] = $staff['faculty_id'];
                $response = ['success' => true, 'redirect' => 'teacherpages/teacherdashboard.php'];
            }
        } elseif ($roleName === 'student') {
            // Validate Student Login
            $query = "SELECT * FROM studentlog WHERE username = '$username' AND password = '$password'";
            $result = $conn->query($query);

            if ($result && $result->num_rows === 1) {
                $student = $result->fetch_assoc();
                $_SESSION['user_id'] = $student['sid'];
                $_SESSION['user_name'] = $student['name'];
                $_SESSION['user_type'] = 'Student';
                $_SESSION['faculty_type'] = $student['faculty'];
                $response = ['success' => true, 'redirect' => 'studentpages/studentdashboard.php'];
            }
        } else {
            $response['message'] = 'Invalid role type.';
        }
    } else {
        $response['message'] = 'Role not found.';
    }

    echo json_encode($response);
    exit;
}

$conn = new mysqli('localhost', 'root', 'your_password', 'issystem');


?>



<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My College - Your Guide to Future</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .hero {
            background-image: url('images/view.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 150px 0; /* Increased padding for more vertical space */
            text-align: center;
            height: 100vh; /* Set the hero section to fill the full viewport height */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .hero h1 {
            font-size: 3rem; /* Adjusted font size for the heading */
            font-weight: bold;
        }

        .hero p {
            font-size: 1.5rem; /* Adjusted font size for the subheading */
            margin-top: 10px;
        }

        .hero .btn {
            font-size: 1.2rem;
            padding: 10px 20px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- NAVIGATION BAR -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white px-lg-3 py-lg-2 fixed-top">
        <div class="container-fluid">
            <!-- Logo Section -->
            <img src="<?php echo htmlspecialchars($logoURL); ?>" alt="My College Logo" style="height: 50px;">

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link me-2" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-2" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link me-2" href="#">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <button class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loginModalLabel">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="loginForm" class="border shadow p-3 rounded" method="POST">
                        <h1 class="text-center p-3">User Login</h1>
                        <div id="errorMessage" class="alert alert-danger d-none"></div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" id="username" required placeholder="Enter Username">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="password" id="password" required placeholder="Enter Password">
                                <span class="input-group-text" id="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                        </div>
                        <div class="mb-0">
                            <label class="form-label">Select User Type</label>
                        </div>
                        <select class="form-select mb-3" name="user_type" required>
                            <option selected disabled>Select User Type</option>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo htmlspecialchars($role['rid']); ?>">
                                    <?php echo htmlspecialchars($role['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="d-flex align-items-center justify-content-between mb-2"> 
                            <button type="submit" class="btn btn-primary">LOGIN</button>
                            <?php if (isset($errorMessage)) { echo "<p>$errorMessage</p>"; } ?>
                            <a href="javascript: void(0)" class="text-secondary text-decoration-none ms-auto">Forgot Password?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- HERO SECTION -->
    <section class="hero d-flex align-items-center justify-content-center">
        
        <div class="container">
            <h1>Your Guide to Future</h1>
            <p>Turning passion into a future through innovation and academic success.</p>
            <a href="#about" class="btn btn-primary mt-3">Learn More</a>
        </div>
    </section>

    <!-- ABOUT SECTION -->
    <section id="about" class="container mt-5">
        <h2 class="section-title">My College</h2>
        <p class="text-center">A college experience that transcends beyond classrooms and lecture theatres.</p>
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card">
                    <img src="images/play1.jpg" class="card-img-top" alt="Event Image">
                    <div class="card-body">
                        <h5 class="card-title">Fun-Filled Events</h5>
                        <p class="card-text">Our college offers exciting events year-round that enrich your experience.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images/play2.jpg" class="card-img-top" alt="Campus Image">
                    <div class="card-body">
                        <h5 class="card-title">Beautiful Campus</h5>
                        <p class="card-text">Study in an inspiring environment with state-of-the-art facilities.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="images/school3.jpg" class="card-img-top" alt="Faculty Image">
                    <div class="card-body">
                        <h5 class="card-title">Experienced Faculty</h5>
                        <p class="card-text">Learn from the best educators who are committed to your success.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="mt-5">
        <div class="container">
            <p>&copy; 2024 My College. All rights reserved.</p>
            <p>
                <a href="#">Contact Us</a> | <a href="#">Privacy Policy</a>
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.getElementById("toggle-password").addEventListener("click", function () {
        const passwordInput = document.getElementById("password");
        const icon = this.querySelector("i");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        } else {
            passwordInput.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }
    });

        $(document).ready(function() {
            $('#loginForm').on('submit', function(event) {
                event.preventDefault(); // Prevent normal form submission
                var formData = $(this).serialize() + '&ajax=1'; // Serialize form data and add ajax parameter
                
                $.ajax({
                    type: 'POST',
                    url: '', // Submit to the same page
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            window.location.href = response.redirect; // Redirect to the dashboard
                        } else {
                            $('#errorMessage').removeClass('d-none').text(response.message); // Show error message
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>
