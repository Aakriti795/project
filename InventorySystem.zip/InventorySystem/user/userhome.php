




<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "issystem";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to calculate total sales (sum of all sales)
$salesQuery = "SELECT SUM(total_amount) AS total_sales FROM bill_history";
$salesResult = $conn->query($salesQuery);

// Fetch total sales
$totalSales = 0;
if ($salesResult && $row = $salesResult->fetch_assoc()) {
    $totalSales = $row['total_sales'];
}

// Query to calculate daily sales (for graph)
$salesGraphQuery = "SELECT DATE(created_at) AS sale_date, SUM(total_amount) AS daily_sales FROM bill_history GROUP BY sale_date ORDER BY sale_date DESC";
$salesGraphResult = $conn->query($salesGraphQuery);

$salesData = [];
$dates = [];
if ($salesGraphResult) {
    while ($row = $salesGraphResult->fetch_assoc()) {
        $salesData[] = $row['daily_sales'];
        $dates[] = $row['sale_date'];
    }
}

// Convert PHP arrays to JSON format for JavaScript
$salesDataJson = json_encode($salesData);
$datesJson = json_encode($dates);
?>








<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User dashboard</title>
    <link rel="stylesheet" href="userhome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>

.content {
            flex-grow: 1;
            padding: 30px;
            background-color: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            font-size: 2.5rem;
            color: #34495e;
        }

        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .stats .card {
            background-color: #1abc9c;
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 45%;
            transition: transform 0.3s ease;
        }

        .stats .card:hover {
            transform: translateY(-5px);
        }

        .stats .card h3 {
            font-size: 1.5rem;
        }

        .chart {
            margin-top: 50px;
        }

        canvas {
            max-width: 100%;
            border-radius: 10px;
        }
    </style>




</head>

<body>

    <div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                    <li><a href="userhome.php" class="active"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="userproduct.php"><i class="fas fa-box"></i> Product</a></li>
                    <li><a href="userbilling.php"><i class="fas fa-file-invoice"></i> Billing</a></li>
                    <li><a href="billhistory.php"><i class="fas fa-history"></i> Bill History </a></li>
                    <li><a href="../index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                   
                </ul>
            </nav>
        </aside>
        <main class="content">
            <header class="header">
                <h1>WECOME USER!</h1>
               
            </header>
            <br>
            <br>
            <section class="stats">
    <div class="card">
        <h3>Total Sales</h3>
        <p><?php echo number_format($totalSales, 2); ?></p> <!-- Display total sales -->

    </div>
</section>




<section class="chart">
    <h2>Total Sales Graph of recent days</h2>
    <canvas id="salesChart" width="400" height="200"></canvas>
</section>






            <section class="recent">
                <h2>Daily Remainder</h2>
                <ul>
                    <li>Logged in at 10:00 AM</li>
                  
                </ul>
            </section>
        </main>
    </div>










    <script>
// Get PHP data into JavaScript
var salesData = <?php echo $salesDataJson; ?>;
var dates = <?php echo $datesJson; ?>;

// Get the canvas element
var ctx = document.getElementById('salesChart').getContext('2d');

// Create a new chart
var salesChart = new Chart(ctx, {
    type: 'line', // Change to 'bar' for a bar chart
    data: {
        labels: dates, // The dates will be on the x-axis
        datasets: [{
            label: 'Total Sales',
            data: salesData, // The sales amounts will be plotted on the y-axis
            borderColor: '#4CAF50',
            fill: false, // Set to true if you want a filled area
            tension: 0.1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            title: {
                display: true,
                text: 'Total Sales Over Time'
            },
            tooltip: {
                callbacks: {
                    label: function(tooltipItem) {
                        return 'Sales: $' + tooltipItem.raw.toFixed(2);
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Sales Amount ($)'
                }
            },
            x: {
                title: {
                    display: true,
                    text: 'Date'
                }
            }
        }
    }
});
</script>












</body>

</html>