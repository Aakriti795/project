<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "issystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents('php://input'), true);

if (!empty($data)) {
    foreach ($data['invoiceData'] as $invoice) {
        $item_name = $invoice['item_name'];
        $quantity = $invoice['quantity'];
        $price = $invoice['price'];
        $amount = $invoice['amount'];
        $total_amount = $data['totalAmount'];
        $received = $data['received'];
        $balance = $data['balance'];

        $query = "INSERT INTO bill_history (item_name, quantity, price, amount, total_amount, received, balance, created_at)
                  VALUES ('$item_name', $quantity, $price, $amount, $total_amount, $received, $balance, NOW())";

        if ($conn->query($query) === TRUE) {
            $response = ['success' => true];
        } else {
            $response = ['success' => false, 'error' => $conn->error];
        }
    }
} else {
    $response = ['success' => false, 'error' => 'No data received.'];
}

echo json_encode($response);
$conn->close();
?>
