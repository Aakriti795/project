<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="userhome.css">
    <style>
        .settings-form {
            max-width: 600px;
            margin: 20px auto;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .settings-form h2 {
            margin-bottom: 15px;
            font-size: 24px;
            color: #333;
        }
        .settings-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .settings-form input, .settings-form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .settings-form button {
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            border: none;
        }
        .settings-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                    <li><a href="userhome.php">Home</a></li>
                    <li><a href="userproduct.php">Product</a></li>
                    <li><a href="userbilling.php">Billing</a></li>
                    <li><a href="userreport.php">Report</a></li>
                    <li><a href="usersetting.php" class="active">Setting</a></li>
                </ul>
            </nav>
        </aside>
        <main class="content">
            <header class="header">
                <h2>Settings</h2>
                <button class="btn">profile</button>
                <button class="btn">user Information</button>
                <button class="btn">Logout</button>
            </header>
            <section class="settings-form">
                <h2>Update Profile</h2>
                <form action="update_profile.php" method="post" onsubmit="return validateForm()">
                    <label for="username">Change Username:</label>
                    <input type="text" id="username" name="username" placeholder="Enter new username" required>

                    <label for="current-password">Current Password:</label>
                    <input type="password" id="current-password" name="current_password" placeholder="Enter current password" required>

                    <label for="new-password">New Password:</label>
                    <input type="password" id="new-password" name="new_password" placeholder="Enter new password" required>

                    <label for="confirm-password">Confirm New Password:</label>
                    <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm new password" required>

                    <label for="email">Change Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter new email" required>

                    <label for="profile-picture">Change Profile Picture:</label>
                    <input type="file" id="profile-picture" name="profile_picture" accept="image/*">

                    <button type="submit">Save Changes</button>
                </form>
            </section>
        </main>
    </div>

    <script>
        function validateForm() {
            const newPassword = document.getElementById('new-password').value;
            const confirmPassword = document.getElementById('confirm-password').value;

            if (newPassword !== confirmPassword) {
                alert('New password and confirm password do not match!');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
