<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "issystem";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch products
$sql = "
    SELECT 
        p.productid, 
        p.productname, 
        p.cp, 
        p.sp, 
        p.description, 
        p.Qty, 
        s.name AS supplier_name
    FROM productinfo p
    LEFT JOIN supplier s ON p.suppliers = s.supid
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link rel="stylesheet" href="userhome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 90%;
            margin: 20px auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        canvas {
            max-width: 600px;
            margin: 0 auto;
        }
    </style>
</head>

<body>
   
<div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                <li><a href="userhome.php" class="active"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="userproduct.php"><i class="fas fa-box"></i> Product</a></li>
                    <li><a href="userbilling.php"><i class="fas fa-file-invoice"></i> Billing</a></li>
                   
                    <li><a href="billhistory.php"><i class="fas fa-file-invoice"></i> Bill History </a></li>
                    <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        <div class="container">
            <h2>Available Products</h2>
            <table id="productTable">
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Cost Price</th>
                        <th>Selling Price</th>
                        <th>Supplier</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . htmlspecialchars($row['productid']) . "</td>
                                <td>" . htmlspecialchars($row['productname']) . "</td>
                                <td>" . htmlspecialchars($row['Qty'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['cp'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['sp'] ?? '0') . "</td>
                                <td>" . htmlspecialchars($row['supplier_name'] ?? 'N/A') . "</td>
                                <td>" . htmlspecialchars($row['description'] ?? '') . "</td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No products available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <canvas id="productChart"></canvas>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('productChart').getContext('2d');
            const table = document.getElementById('productTable');
            const rows = Array.from(table.tBodies[0].rows);

            const productNames = rows.map(row => row.cells[1].innerText);
            const quantities = rows.map(row => parseInt(row.cells[2].innerText));

            const data = {
                labels: productNames,
                datasets: [{
                    label: 'Product Quantities',
                    data: quantities,
                    backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56', '#2ecc71', '#3498db', '#f1c40f'],
                }]
            };

            const config = {
                type: 'pie',
                data: data,
            };

            const productChart = new Chart(ctx, config);

            const observer = new MutationObserver(() => {
                const updatedProductNames = rows.map(row => row.cells[1].innerText);
                const updatedQuantities = rows.map(row => parseInt(row.cells[2].innerText));
                
                productChart.data.labels = updatedProductNames;
                productChart.data.datasets[0].data = updatedQuantities;
                productChart.update();
            });

            observer.observe(table.tBodies[0], { childList: true, subtree: true });
        });
    </script>
</body>

</html>

<?php
$conn->close();
?>
