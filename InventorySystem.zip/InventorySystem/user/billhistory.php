<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "issystem";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Correct usage of the query() method
$query = "SELECT * FROM bill_history ORDER BY created_at DESC";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bill History</title>
    <link rel="stylesheet" href="userhome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">



<style>

    /* General Styling for the Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border: 1px solid #ddd;
}

th {
    background-color: #4CAF50;
    color: white;
    font-size: 16px;
}

td {
    font-size: 14px;
    color: #333;
}

/* Hover Effect */
tr:hover {
    background-color: #f2f2f2;
}

/* Alternating Row Colors */
tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

tbody tr:nth-child(odd) {
    background-color: #fff;
}

/* Table Container */
.table-container {
    overflow-x: auto;
    margin-top: 20px;
}

/* Table Headings */
th {
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* Adding shadows to the table for a more polished look */
table {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Responsive Table */
@media (max-width: 768px) {
    table {
        font-size: 12px;
    }

    th, td {
        padding: 8px;
    }
}


</style>



</head>

<body>
    <div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                    <li><a href="userhome.php"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="userproduct.php"><i class="fas fa-box"></i> Product</a></li>
                    <li><a href="userbilling.php"><i class="fas fa-file-invoice"></i> Billing</a></li>
                    
                    <li><a href="billhistory.php" class="active"><i class="fas fa-file-invoice"></i> Bill History</a></li>
                    <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </nav>
        </aside>
        <main class="content">
            <h2>Bill Report </h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Amount</th>
                            <th>Total Amount</th>
                            <th>Received</th>
                            <th>Return Amount</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['item_name']}</td>
                                    <td>{$row['quantity']}</td>
                                    <td>{$row['price']}</td>
                                    <td>{$row['amount']}</td>
                                    <td>{$row['total_amount']}</td>
                                    <td>{$row['received']}</td>
                                    <td>{$row['balance']}</td>
                                    <td>{$row['created_at']}</td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='9'>No records found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>

</html>
