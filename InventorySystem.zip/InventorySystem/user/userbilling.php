<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle the AJAX request
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['productId'])) {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "issystem";
        $productId = $data['productId'];
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        $query = "SELECT * FROM productinfo where productid=$productId";

        // FETCHING DATA FROM DATABASE 
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            // OUTPUT DATA OF EACH ROW 
            while ($row = $result->fetch_assoc()) {
                echo json_encode(['response' => htmlspecialchars($row["sp"])]);
            }
        } else {
            echo "0 results";
        }
        exit;
    } else {
        echo json_encode(['response' => "No data received!"]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing</title>
    <link rel="stylesheet" href="userhome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>

<body>

<div class="dashboard">
        <aside class="sidebar">
            <img src="logo.png" alt="System logo" class="logo">
            <nav>
                <ul>
                <li><a href="userhome.php" class="active"><i class="fas fa-home"></i> Home</a></li>
                    <li><a href="userproduct.php"><i class="fas fa-box"></i> Product</a></li>
                    <li><a href="userbilling.php"><i class="fas fa-file-invoice"></i> Billing</a></li>
                  
                    <li><a href="billhistory.php"><i class="fa fa-history"></i> Bill History </a></li>
                    <li><a href="C:\xampp\htdocs\InventorySystem\index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                   
                </ul>
            </nav>
        </aside>
        <main class="content">
            <h2>Billing</h2>
            <div class="header">
                <img src="logo.png" alt="Logo" class="logo">
                <h1>A Cube</h1>
                <p>Phone: 9826162026</p>
                <p>Email: acubepvtltd@gmail.com</p>
            </div>

            <div class="table-container">
                <table id="invoice-table">
                    <thead>
                        <tr>
                            <th>S.N</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price/Unit (Rs)</th>
                            <th>Amount (Rs)</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="invoice-body">
                        <tr>
                            <td>1</td>
                            <td><select id="product" onchange="getPrice(this)">
                                    <option>select a item</option>
                                    <?php
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $database = "issystem";

                                    // Create connection
                                    $conn = mysqli_connect($servername, $username, $password, $database);
                                    $query = "SELECT * FROM productinfo";

                                    // FETCHING DATA FROM DATABASE 
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        // OUTPUT DATA OF EACH ROW 
                                        while ($row = $result->fetch_assoc()) {
                                            $productId = $row["productid"];
                                            $productName = $row["productname"];
                                            echo "<option value='$productId'>$productName</option>";
                                        }
                                    } else {
                                        echo "0 results";
                                    }
                                    ?>
                                </select></td>
                            <td><input type="number" class="input-field" placeholder="Quantity" oninput="calculateAmount()"></td>
                            <td></td>
                            <td><input type="text" disabled placeholder="Amount" class="input-field"></td>
                            <td>
                                <button onclick="deleteRow(this)">Delete</button>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4"><strong>Total</strong></td>
                            <td><strong><span id="total-amount">Rs 0.00</span></strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
                <button onclick="addItem()">Add Item</button>
            </div>

            <div class="total">
                <p>Invoice Amount in Words: <span id="amount-in-words">Zero Rupees only</span></p>
                <p>Received: Rs <input type="number" id="received" value="0" oninput="calculateBalance()"></p>
                <p>Balance: Rs <span id="balance">0.00</span></p>
            </div>

            <!-- Buttons for Save and Print -->
            <div class="actions">
                <button onclick="saveInvoice()">Save</button>
                <button onclick="printInvoice()">Print</button>
            </div>

            <script>
                function getPrice(x) {
                    const table = document.getElementById("invoice-table");
                    const row = table.rows[x.closest('tr').rowIndex];
                    const cell=row.cells[1];
                    selectField=cell.querySelector("select")
                    const data = {
                        productId: selectField.value
                    };

                    fetch('', { // '' targets the current page
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            body: JSON.stringify(data),
                        })
                        .then(response => response.json())
                        .then(result => {
                            // Update the page with the response
                            row.cells[3].textContent = result.response;
                        })
                        .catch(error => {
                            console.error('Error:', error);
                        });
                }
                let rowCount = 1;

                // Function to add a new row
                function addItem() {
                    rowCount++;
                    const tableBody = document.getElementById('invoice-body');
                    const row = document.createElement('tr');

                    row.innerHTML = ` 
                    <td>${rowCount}</td>
                    <td><select id="product" onchange="getPrice(this)">
                                    <option>select a item</option>
                                    <?php
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $database = "issystem";

                                    // Create connection
                                    $conn = mysqli_connect($servername, $username, $password, $database);
                                    $query = "SELECT * FROM productinfo";

                                    // FETCHING DATA FROM DATABASE 
                                    $result = $conn->query($query);

                                    if ($result->num_rows > 0) {
                                        // OUTPUT DATA OF EACH ROW 
                                        while ($row = $result->fetch_assoc()) {
                                            $productId = $row["productid"];
                                            $productName = $row["productname"];
                                            echo "<option value='$productId'>$productName</option>";
                                        }
                                    } else {
                                        echo "0 results";
                                    }
                                    ?>
                                </select></td>
                            <td><input type="number" class="input-field" placeholder="Quantity" oninput="calculateAmount()"></td>
                            <td><b id="productPrice${rowCount}"></b></td>
                            <td><input type="text" disabled placeholder="Amount" class="input-field"></td>
                            <td>
                                <button onclick="deleteRow(this)">Delete</button>
                            </td>
                `;
                    tableBody.appendChild(row);
                }

                // Function to delete a row
                function deleteRow(button) {
                    const row = button.parentElement.parentElement;
                    row.remove();
                    updateSerialNumbers();
                    calculateAmount();
                }

                // Update serial numbers after a row is deleted
                function updateSerialNumbers() {
                    const rows = document.querySelectorAll('#invoice-body tr');
                    rowCount = rows.length;
                    rows.forEach((row, index) => {
                        row.children[0].textContent = index + 1;
                    });
                }

                // Function to calculate amounts and total
                function calculateAmount() {
                    const rows = document.querySelectorAll('#invoice-body tr');
                    let totalAmount = 0;

                    rows.forEach(row => {
                        const qty = row.children[2].children[0].value;
                        const price = row.children[3].textContent;
                        const amount = qty * price || 0;
                        row.children[4].children[0].value = amount.toFixed(2);
                        totalAmount += amount;
                    });

                    document.getElementById('total-amount').textContent = 'Rs ' + totalAmount.toFixed(2);

                    const words = convertNumberToWords(totalAmount);
                    document.getElementById('amount-in-words').textContent = words + ' Rupees only';

                    calculateBalance();
                }

                // Function to calculate balance
                function calculateBalance() {
                    const totalAmount = parseFloat(document.getElementById('total-amount').textContent.replace('Rs ', ''));
                    const received = parseFloat(document.getElementById('received').value) || 0;
                    const balance = totalAmount - received;
                    document.getElementById('balance').textContent = balance.toFixed(2);
                }

                

                // Convert number to words
                function convertNumberToWords(num) {
                    const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
                    const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

                    if (num === 0) return 'Zero';

                    const n = num.toString().split('.');
                    const intPart = parseInt(n[0], 10);
                    const decimalPart = n[1] ? parseInt(n[1].substring(0, 2), 10) : 0;

                    function numberToWords(n, suffix) {
                        if (n === 0) return '';
                        if (n < 20) return a[n] + ' ' + suffix;
                        if (n < 100) return b[Math.floor(n / 10)] + ' ' + a[n % 10] + ' ' + suffix;
                        if (n < 1000) return a[Math.floor(n / 100)] + ' Hundred ' + (n % 100 !== 0 ? 'and ' + numberToWords(n % 100, '') : '') + suffix;
                        return '';
                    }

                    let words = '';
                    let tempNum = intPart;
                    let place = 0;

                    while (tempNum > 0) {
                        const remainder = tempNum % 1000;
                        if (remainder) words = numberToWords(remainder, ['Thousand', 'Lakh', 'Crore'][place - 1] || '') + ' ' + words;
                        tempNum = Math.floor(tempNum / 1000);
                        place++;
                    }

                    if (decimalPart > 0) words += ' and ' + numberToWords(decimalPart, '') + ' Paise';

                    return words.trim();
                }

                function saveInvoice() {
    const rows = document.querySelectorAll('#invoice-body tr');
    const invoiceData = [];

    rows.forEach(row => {
        const itemName = row.children[1].children[0].value;
        const quantity = row.children[2].children[0].value;
        const price = row.children[3].textContent;
        const amount = row.children[4].children[0].value;

        invoiceData.push({
            item_name: itemName,
            quantity: quantity,
            price: price,
            amount: amount
        });
    });

    const totalAmount = parseFloat(document.getElementById('total-amount').textContent.replace('Rs ', ''));
    const received = parseFloat(document.getElementById('received').value) || 0;
    const balance = parseFloat(document.getElementById('balance').textContent);

    const data = {
        invoiceData: invoiceData,
        totalAmount: totalAmount,
        received: received,
        balance: balance
    };

    fetch('save_invoice.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert('Invoice saved successfully!');
            } else {
                alert('Failed to save invoice.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}


                // Print invoice
                function printInvoice() {
                    if (validateBeforePrint()) {
                        window.print();
                    }
                }
            </script>
        </main>
    </div>
</body>

</html>